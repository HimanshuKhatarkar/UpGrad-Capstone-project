import {
    Button,
    Card,
    CardHeader,
    CardContent,
    TextField,
    FormControl,
    FormHelperText,
    InputLabel,
    Select,
    MenuItem,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogContentText,
    DialogActions,
    Typography
} from '@material-ui/core';
import { Language } from '@material-ui/icons';
import Modal from "react-modal/lib/components/Modal";
import { MuiPickersUtilsProvider, KeyboardDatePicker } from '@material-ui/pickers';
import DateFnsUtils from '@date-io/date-fns';
import { customModalStyles } from '../../common/header/Header';
import { useContext, useEffect, useState } from 'react';
import { UserContext } from '../Controller';
import { fetchData } from '../../util/fetch';
import '../../common/header/Header.css';

const TIME_SLOTS = [
    "09AM-10AM", "10AM-11AM", "11AM-12PM", "12PM-01PM",
    "01PM-02PM", "02PM-03PM", "03PM-04PM", "04PM-05PM",
    "05PM-06PM", "06PM-07PM", "07PM-08PM", "08PM-09PM",
    "09PM-10PM", "10PM-11PM"
];

const INITIAL_FORM_DATA = {
    doctorId: '',
    doctorName: '',
    userId: '',
    userName: '',
    userEmailId: '',
    timeSlot: 'None',
    appointmentDate: new Date().toISOString().split('T')[0],
    createdDate: '',
    priorMedicalHistory: '',
    symptoms: ''
};

const ErrorDialog = ({ isOpen, message, onClose }) => (
    <Dialog
        open={isOpen}
        onClose={onClose}
        aria-labelledby="error-dialog-title"
    >
        <DialogTitle disableTypography>
            <Typography component="h2" className="icon-header">
                <Language />
                {window.location.host}
            </Typography>
        </DialogTitle>
        <DialogContent>
            <DialogContentText>
                {message}
            </DialogContentText>
        </DialogContent>
        <DialogActions>
            <Button variant='contained' color='primary' onClick={onClose} autoFocus>
                Ok
            </Button>
        </DialogActions>
    </Dialog>
);

const AppointmentForm = ({ formData, onFieldChange, onDateChange, onSubmit, timeSlotError }) => (
    <CardContent className='book-appointment-form'>
        <div>
            <TextField 
                label="DoctorName" 
                value={formData.doctorName} 
                disabled 
                required 
            />
        </div>
        <div>
            <MuiPickersUtilsProvider utils={DateFnsUtils}>
                <KeyboardDatePicker
                    disableToolbar
                    variant="inline"
                    format="MM/dd/yyyy"
                    margin="normal"
                    id="date-picker-inline"
                    label="Date picker inline"
                    value={formData.appointmentDate}
                    onChange={onDateChange}
                    KeyboardButtonProps={{
                        'aria-label': 'change date',
                    }}
                    autoOk
                />
            </MuiPickersUtilsProvider>
        </div>
        <div>
            <FormControl className='select-width'>
                <InputLabel>Timeslot</InputLabel>
                <Select 
                    name='timeSlot' 
                    value={formData.timeSlot} 
                    onChange={onFieldChange}
                >
                    <MenuItem value='None'>None</MenuItem>
                    {TIME_SLOTS.map(slot => (
                        <MenuItem key={slot} value={slot}>{slot}</MenuItem>
                    ))}
                </Select>
                {timeSlotError && (
                    <FormHelperText error>Select a time slot</FormHelperText>
                )}
            </FormControl>
        </div>
        <div>
            <TextField
                multiline
                minRows={1}
                value={formData.priorMedicalHistory || ''}
                variant="standard"
                name='priorMedicalHistory'
                label='Medical History'
                onChange={onFieldChange}
            />
        </div>
        <div>
            <TextField
                multiline
                minRows={1}
                value={formData.symptoms || ''}
                variant="standard"
                name='symptoms'
                label='Symptoms'
                placeholder="ex:Cold, Swelling, etc"
                onChange={onFieldChange}
            />
        </div>
        <Button 
            variant="contained" 
            color='primary' 
            className='book-appointment-btn' 
            onClick={onSubmit}
        >
            BOOK APPOINTMENT
        </Button>
    </CardContent>
);

const BookAppointment = ({ showBookAppointmentModal = false, setShowBookAppointmentModal, doctor }) => {
    const { currentUser } = useContext(UserContext);
    const [errorState, setErrorState] = useState({ show: false, message: '' });
    const [formData, setFormData] = useState(INITIAL_FORM_DATA);
    const [timeSlotError, setTimeSlotError] = useState(false);

    useEffect(() => {
        if (currentUser && doctor) {
            setFormData({
                ...INITIAL_FORM_DATA,
                doctorId: doctor.id,
                doctorName: `${doctor.firstName} ${doctor.lastName}`,
                userId: currentUser.id,
                userName: currentUser.firstName,
                userEmailId: currentUser.emailAddress,
            });
        }
    }, [doctor, currentUser]);

    const handleFieldChange = (event) => {
        const { name, value } = event.target;
        setFormData(prev => ({ ...prev, [name]: value }));
        
        if (name === 'timeSlot') {
            setTimeSlotError(value === 'None');
        }
    };

    const handleDateChange = (date) => {
        setFormData(prev => ({
            ...prev,
            appointmentDate: date.toISOString().split('T')[0]
        }));
    };

    const handleErrorMessage = (showError, message) => {
        const displayMessage = message === 'This slot is unavailable'
            ? 'Either the slot is already booked or not available'
            : message;
        setErrorState({ show: showError, message: displayMessage });
    };

    const handleSubmit = async () => {
        if (formData.timeSlot === 'None') {
            setTimeSlotError(true);
            return;
        }

        const [, hasError] = await fetchData(
            'appointments',
            {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${currentUser.accessToken}`,
                },
                body: JSON.stringify(formData),
            },
            handleErrorMessage
        );

        if (!hasError) {
            setShowBookAppointmentModal(false);
        }
    };

    const modalStyle = { 
        content: { 
            ...customModalStyles.content, 
            width: '50%' 
        } 
    };

    return (
        <>
            <Modal
                isOpen={showBookAppointmentModal}
                onRequestClose={() => setShowBookAppointmentModal(false)}
                style={modalStyle}
                contentLabel="Book an Appointment"
            >
                <Card>
                    <CardHeader 
                        className="modal-header" 
                        title="Book an Appointment" 
                    />
                    <AppointmentForm
                        formData={formData}
                        onFieldChange={handleFieldChange}
                        onDateChange={handleDateChange}
                        onSubmit={handleSubmit}
                        timeSlotError={timeSlotError}
                    />
                </Card>
            </Modal>
            
            <ErrorDialog
                isOpen={errorState.show}
                message={errorState.message}
                onClose={() => setErrorState({ show: false, message: '' })}
            />
        </>
    );
};

export default BookAppointment;