import { useContext, useEffect, useState } from "react";
import { fetchData } from "../../util/fetch";
import { SnackbarContext, UserContext } from "../Controller";
import { Button, Paper, Typography } from '@material-ui/core';
import RateAppointment from "./RateAppointment";
import "./Appointment.css";

const AppointmentCard = ({ appointment, onRate }) => (
    <Paper key={`appointment-${appointment.id}`} className="app-card">
        <Typography variant="h6">Dr: {appointment.doctorName}</Typography>
        <Typography variant="h6">Date: {appointment.appointmentDate}</Typography>
        <Typography variant="h6">Symptoms: {appointment.symptoms}</Typography>
        <Typography variant="h6" className="lrg-txt">
            Prior Medical History: {appointment.priorMedicalHistory}
        </Typography>
        <Button 
            variant="contained" 
            color="primary"
            onClick={() => onRate(appointment)}
        >
            RATE APPOINTMENT
        </Button>
    </Paper>
);

const AppointmentsList = () => {
    const { currentUser } = useContext(UserContext);
    const { showNotification } = useContext(SnackbarContext);
    const [appointments, setAppointments] = useState([]);
    const [isRatingModalOpen, setIsRatingModalOpen] = useState(false);
    const [selectedAppointment, setSelectedAppointment] = useState(null);

    const fetchAppointments = async () => {
        if (!currentUser) return;

        const [response, hasError] = await fetchData(
            `users/${currentUser.id}/appointments`,
            {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${currentUser.accessToken}`
                }
            },
            showNotification
        );

        if (!hasError && response) {
            setAppointments(JSON.parse(response));
        }
    };

    useEffect(() => {
        fetchAppointments();
    }, [currentUser]);

    const handleRateAppointment = (appointment) => {
        setSelectedAppointment(appointment);
        setIsRatingModalOpen(true);
    };

    if (!currentUser) {
        return <p className="body-text">Login to see appointments</p>;
    }

    return (
        <div>
            <div className="app-appointment-list">
                {appointments.map((appointment) => (
                    <AppointmentCard
                        key={appointment.id}
                        appointment={appointment}
                        onRate={handleRateAppointment}
                    />
                ))}
            </div>
            <RateAppointment
                showRateAppointmentModal={isRatingModalOpen}
                setShowRateAppointmentModal={setIsRatingModalOpen}
                appointment={selectedAppointment}
            />
        </div>
    );
};

export default AppointmentsList;